<?php
	$a=$_GET[]
?>