window.onload = function(){
	var arr = [];
	var N = 10;
	for(var i=0;i<N;i++){
		arr.push(i*Math.random());
	}
	console.log(arr);
};